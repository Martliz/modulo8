import { Sequelize } from 'sequelize';

const db = new Sequelize('db_jwtbootcamp', 'postgres', 'martha1', {
  host: 'localhost',
  dialect: 'postgres',
});

export default db;

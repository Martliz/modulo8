export default {
    secret: 'mi_secreto_super_seguro',
  };
  
import { Bootcamp, User } from '../models/index.js';

// Crear y guardar un nuevo Bootcamp
export const createBootcamp = async (req, res) => {
  try {
    const { title, cue, description } = req.body;
    const newBootcamp = await Bootcamp.create({ title, cue, description });
    res.status(201).json({ message: 'Bootcamp creado exitosamente', data: newBootcamp });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al crear el Bootcamp' });
  }
};

// Agregar un usuario al Bootcamp
export const addUser = async (req, res) => {
  try {
    const { bootcampId, userId } = req.body;

    const bootcamp = await Bootcamp.findByPk(bootcampId);
    if (!bootcamp) {
      return res.status(404).json({ message: 'Bootcamp no encontrado' });
    }

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'Usuario no encontrado' });
    }

    await bootcamp.addUser(user);
    res.status(200).json({ message: 'Usuario agregado al Bootcamp exitosamente' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al agregar el usuario al Bootcamp' });
  }
};

// Obtener un Bootcamp por ID
export const findById = async (req, res) => {
  try {
    const { id } = req.params;
    const bootcamp = await Bootcamp.findByPk(id, { include: User });

    if (!bootcamp) {
      return res.status(404).json({ message: 'Bootcamp no encontrado' });
    }

    res.status(200).json(bootcamp);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al obtener el Bootcamp' });
  }
};

// Obtener todos los Bootcamps incluyendo los usuarios
export const findAll = async (req, res) => {
  try {
    const bootcamps = await Bootcamp.findAll({ include: User });
    res.status(200).json(bootcamps);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al obtener los Bootcamps' });
  }
};

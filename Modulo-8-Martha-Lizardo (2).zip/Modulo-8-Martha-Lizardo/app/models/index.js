import db from '../config/db.config.js';
import User from './user.model.js';
import Bootcamp from './bootcamp.model.js';

// Relación muchos a muchos
User.belongsToMany(Bootcamp, { through: 'UserBootcamps' });
Bootcamp.belongsToMany(User, { through: 'UserBootcamps' });

export { db, User, Bootcamp };

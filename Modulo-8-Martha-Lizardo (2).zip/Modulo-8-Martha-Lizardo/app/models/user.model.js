import { DataTypes } from 'sequelize';
import db from '../config/db.config.js';

// Definición del modelo User
const User = db.define('User', {
  firstName: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  lastName: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    validate: {
      isEmail: true,
    },
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      len: [8, 128], // Longitud mínima de 8 caracteres
    },
  },
});

export default User;

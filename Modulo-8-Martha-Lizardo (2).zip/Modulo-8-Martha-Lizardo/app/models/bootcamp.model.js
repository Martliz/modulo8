import { DataTypes } from 'sequelize';
import db from '../config/db.config.js';

const Bootcamp = db.define('Bootcamp', {
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  cue: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 5,
      max: 18,
    },
  },
  description: {
    type: DataTypes.STRING,
    allowNull: false,
  },
});

export default Bootcamp;

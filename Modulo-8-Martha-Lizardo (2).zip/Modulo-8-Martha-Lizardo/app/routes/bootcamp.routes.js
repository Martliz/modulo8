router.post('/bootcamp', verifyToken, createBootcamp);
router.post('/bootcamp/adduser', verifyToken, addUserToBootcamp);
router.get('/bootcamp/:id', verifyToken, findBootcampById);
router.get('/bootcamp', findAllBootcamps);

router.post('/signup', createUser);
router.post('/signin', loginUser);
router.get('/user/:id', verifyToken, findUserById);
router.get('/user', verifyToken, findAll);
router.put('/user/:id', verifyToken, updateUserById);
router.delete('/user/:id', verifyToken, deleteUserById);

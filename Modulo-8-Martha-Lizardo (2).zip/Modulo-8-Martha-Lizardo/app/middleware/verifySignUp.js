import Usuario from '../models/user.model.js';

export const checkDuplicateEmail = async (req, res, next) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: 'El correo electrónico es obligatorio.' });
    }

    const user = await Usuario.findOne({ where: { email } });
    if (user) {
      return res.status(400).json({ message: 'El correo electrónico ya está en uso.' });
    }

    next();
  } catch (error) {
    console.error('Error verificando duplicados:', error);
    return res.status(500).json({ message: 'Error en el servidor al verificar el registro.' });
  }
};

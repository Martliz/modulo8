import jwt from 'jsonwebtoken';
import config from '../config/auth.config.js';
import Usuario from '../models/user.model.js';

export const verifyToken = async (req, res, next) => {
  try {
    const token = req.headers['x-access-token'];

    if (!token) {
      return res.status(403).json({ message: 'No se proporcionó un token.' });
    }

    const decoded = jwt.verify(token, config.secret);
    req.userId = decoded.id;

    const user = await Usuario.findByPk(req.userId);
    if (!user) {
      return res.status(404).json({ message: 'Usuario no encontrado.' });
    }

    next();
  } catch (error) {
    console.error('Error verificando el token:', error);
    return res.status(401).json({ message: 'Token inválido.' });
  }
};

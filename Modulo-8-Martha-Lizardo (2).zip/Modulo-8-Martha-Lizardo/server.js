// server.js: Configuración para inicializar la base de datos y crear datos de prueba
import express from 'express';
import { db, User, Bootcamp } from './app/models/index.js';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Conexión a la base de datos y sincronización de modelos
const initializeDatabase = async () => {
  try {
    await db.sync({ force: true }); // Forzar la sincronización para recrear tablas
    console.log('Base de datos sincronizada.');

    // Crear usuarios
    const usuarios = [
      { firstName: 'Mateo', lastName: 'Díaz', email: 'mateo.diaz@correo.com' },
      { firstName: 'Santiago', lastName: 'Mejías', email: 'santiago.mejias@correo.com' },
      { firstName: 'Lucas', lastName: 'Rojas', email: 'lucas.rojas@correo.com' },
      { firstName: 'Facundo', lastName: 'Fernandez', email: 'facundo.fernandez@correo.com' },
    ];
    const createdUsers = await User.bulkCreate(usuarios);
    console.log('Usuarios creados:', createdUsers.map(u => u.toJSON()));

    // Crear bootcamps
    const bootcamps = [
      { title: 'JavaScript Avanzado', cue: 8, description: 'Aprende JS a nivel avanzado.' },
      { title: 'Introducción a Node.js', cue: 6, description: 'Comienza tu camino en Node.js.' },
    ];
    const createdBootcamps = await Bootcamp.bulkCreate(bootcamps);
    console.log('Bootcamps creados:', createdBootcamps.map(b => b.toJSON()));

    // Relacionar usuarios con bootcamps
    await createdBootcamps[0].addUsers([createdUsers[0], createdUsers[1]]);
    await createdBootcamps[1].addUsers([createdUsers[2], createdUsers[3]]);

    console.log('Relaciones creadas entre usuarios y bootcamps.');
  } catch (error) {
    console.error('Error al inicializar la base de datos:', error);
  }
};

// Inicializar la base de datos y comenzar el servidor
initializeDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`Servidor escuchando en http://localhost:${PORT}`);
  });
});
